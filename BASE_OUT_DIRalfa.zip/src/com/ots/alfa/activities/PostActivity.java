package com.ots.alfa.activities;

import android.app.Activity;
import android.os.Bundle;
import com.ots.alfa.R;


public class PostsActivity extends Activity {
	private static final String TAG = "PostsActivity";

	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_post);



	}



}